This code comes from Daniel J. Bernstein's SUPERCOP source,
released in the public domain.

[http://ed25519.cr.yp.to/software.html](http://ed25519.cr.yp.to/software.html)
