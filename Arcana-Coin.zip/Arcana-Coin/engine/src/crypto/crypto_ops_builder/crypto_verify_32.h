#ifndef crypto_verify_32_H
#define crypto_verify_32_H

#define crypto_verify_32_ref_BYTES 32
extern int crypto_verify_32(const unsigned char *,const unsigned char *);

#endif
